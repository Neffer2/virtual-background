Background = require('bnb_js/background');
Background.texture("calamardo.jpg")